# GSS IoT V3 — Project State

## Current phase

`PHASE_8_COMPLETE`

## Last completed milestone

Phase 8 device provisioning and MQTT-backed node assignment are complete as of 2026-07-18. The repository creates active node-to-gateway assignments only after strict successful `cmd=2` gateway acknowledgement, records provisioning intent relationally, rejects invalid selector combinations, publishes legacy-compatible numeric node arrays, owns deterministic MQTT `requestId` correlation from `GatewayCommand.id`, and provides an Admin UI flow without manual UUID entry. Live ESP32 verification completed with explicitly selected gateway `0300`, command `160b3e5c-139d-479b-8535-a82f25f95b02`, and nodes `100`, `101` and `102`.

## Current repository status

- Application source: NestJS API keeps the Phase 1 separate GSS Admin and Company JWT contexts, active-user enforcement, permission resolution, decorators and scope guards.
- Database schema: Prisma RBAC, organization hierarchy, scope-access foundation, Phase 4 device history migration `20260714170000_device_inventory_assignments`, Phase 5 command migration `20260715120000_gateway_command_outbox`, Phase 6 monitoring migration `20260715150000_phase_6_monitoring_realtime` and Phase 8 provisioning migration `20260716120000_phase_8_device_provisioning` applied to `gss_iot_v3`; `prisma migrate status` reports the schema up to date.
- Seed: permission catalog, default GSS/company roles, canonical node types and environment-configured active GSS super admin seeded idempotently.
- Frontend: bearer auth persists only the access token and auth context in `sessionStorage`, restores full sessions from `/auth/gss/me` or `/auth/company/me`, preserves separate GSS Admin and Company route contexts, permission-filters Admin/Company shells, uses context-aware protected NotFound pages, keeps the Phase 2 design-system demo route and renders universal UI states plus legacy image-first node-type cards.
- Phase 3 API: guarded GSS Admin and Company endpoints manage companies, areas, buildings, storage-key image records, company users, company-owned roles, direct permissions, area/building access and scoped position assignments. Critical mutations write audit logs inside their database transactions.
- Phase 3 UI: Admin company creation creates the initial platform manager; Company routes now render scoped area/building lists plus company-user and role management views using the shared Phase 2 shell and UI primitives.
- Phase 4 API: guarded GSS Admin endpoints manage node types, gateway inventory, node inventory, company-device assignment, gateway-building assignment and node-gateway assignment. Company endpoints expose company, area and building scoped device snapshots. Critical create, update, assign, unassign and move operations write audit logs.
- Phase 4 UI: Admin `/admin/devices` renders gateway/node inventory tables, create dialogs and permission-wrapped assignment actions. Company `/company/devices` renders assigned gateways and nodes through the shared shell.
- Phase 5 API: guarded GSS Admin endpoints list, inspect, create, retry, cancel and expire GatewayCommands. Commands are persisted before publish and all publish, acknowledgement, retry, expiration and cancel transitions are audited.
- Phase 5 MQTT: `MQTT_ENABLED=false` keeps local/test runs broker-free; `MQTT_FAKE_ACK=true` simulates publish acknowledgement for E2E and smoke tests. Real broker connection uses validated broker URL, client id, optional credentials, topic base and publish/command timeouts.
- Phase 5 UI: Admin `/admin/gateway-commands` renders the command list, status badges, payload/response detail drawer, retry and cancel actions behind `mqtt-commands.view/manage`.
- Phase 6 API: additive migration `20260715150000_phase_6_monitoring_realtime` adds `SensorReading`, `LatestNodeState` and `SensorReadingStatus`. GSS and Company monitoring endpoints return scoped building overview, node-type latest states and paginated sensor history using `monitoring.view`.
- Phase 6 MQTT: sensor subscriptions cover legacy `GATE_PUB`, `GATE_ANG` and `GATE_FORM` topics. Payload normalization supports door, angle and gangform/vertical naming, validates active gateway/node/company/building assignments and deduplicates packet/message/sequence/measured-time keys.
- Phase 6 Realtime: Socket.IO joins require authenticated active users, `monitoring.realtime` and company building scope where applicable. Rooms are server-created as building/node-type scoped names, and normalized node-state events emit only after reading persistence and latest-state upsert.
- Phase 6 UI: Company monitoring starts at scoped building selection, enters through the three preserved legacy node-type image cards, shows latest value/status/gateway context/value age, keeps last known values across disconnects and displays paginated node history.
- Phase 7 UI: Admin `/admin/companies/:companyId`, `/admin/companies/:companyId/sites`, `/admin/companies/:companyId/buildings`, `/admin/companies/:companyId/users` and `/admin/companies/:companyId/devices` are explicit deep-link-safe routes. The company detail flow shows profile/status, platform managers, construction sites, buildings and assigned gateways/nodes, with create/edit/deactivate actions wrapped in existing permissions and backed by existing guarded APIs.
- Phase 8 API: `REGISTER_NODES` GatewayCommands create a relational `NodeGatewayProvisioningRequest` with per-node items. Successful strict ACK applies active `NodeGatewayAssignment` rows in the ACK transaction; negative ACK, malformed/no-success response, pending/offline, failed, expired, cancelled, duplicate and late responses do not create false active assignments.
- Phase 8 MQTT: Gateway response parsing accepts only documented explicit success values, including the live legacy `{ "cmd": 2, "resp": "success" }` acknowledgement shape at parser level, and preserves raw response payloads. The final stored/published payload for `cmd 2/3/4/5` includes `requestId = GatewayCommand.id`; retries reuse the same id/requestId. Live firmware responses for `cmd 2/3/4/5` now include `cmd` and echo `requestId` when supplied; legacy no-requestId fallback remains supported. Response correlation prefers exact requestId, rejects unknown/malformed/wrong-gateway/wrong-cmd request IDs without fallback, and supports strict legacy gateway-serial-plus-cmd matching only when no requestId is present and exactly one eligible command exists. Cmd 2 register-node and cmd 5 fault-filter adapters convert database string node numbers to safe JSON integers before publish, reject invalid or numerically duplicated node numbers before command persistence, and preserve requested node order. Runtime observability logs disabled mode, sanitized connection lifecycle, subscription success, publish success/failure, raw `GATE_RES` debug payloads, malformed sensor debug payloads and normalized gateway response matching without exposing MQTT credentials.
- Phase 8 UI: Admin `/admin/devices` uses company, building, actively assigned gateway, node type and eligible node selectors for MQTT provisioning. Raw node-to-gateway UUID assignment is removed from the UI; unassign remains explicit DB history only until a hardware unregister/sync command is confirmed.
- Phase 8 observability UI: Admin `/admin/gateway-commands` shows a protected MQTT status block backed by `GET /admin/gateway-commands/mqtt-status`, including enabled/connected state, broker host, client id, subscribed topic filters and last connected/message/publish/error timestamps. MQTT username and password are never returned by the API or rendered in the UI.
- Shared UI: `packages/ui` exports the normalized GSS Mantine theme, page header, data table/pagination footer, status badge, universal states and node-type selection card primitives.
- Runtime configuration: API CORS is environment-driven through `CORS_ALLOWED_ORIGINS`; local development defaults support both `http://localhost:5173` and `http://127.0.0.1:5173`. Auth remains bearer-token based with no login cookies.
- CI: template only
- Quality gates: frozen install, format, lint, typecheck, unit tests, build, API E2E, browser E2E, combined E2E, Prettier check and `git diff --check` pass. `git diff --check` reports only Git line-ending warnings on Windows.
- Architecture blueprint: available
- UI/UX specification: available
- Legacy source archives: available
- Legacy source inventory and preserved node assets: verified
- Custom Codex skill: available

## Verified decisions

- New greenfield monorepo; legacy project is reference only.
- Backend: NestJS + TypeScript.
- Database: PostgreSQL + Prisma.
- Prisma: `prisma` and `@prisma/client` pinned to `6.19.0`.
- Frontend: React + Vite + TypeScript.
- Workspace TypeScript: root solution project references buildable workspace outputs; apps consume shared packages through package exports.
- Primary UI system: Mantine + Tabler icons using Parfumbox admin patterns.
- Colors: normalized GSS palette.
- Realtime: Socket.IO.
- MQTT: durable GatewayCommand outbox.
- RBAC: separate GSS Admin and Company contexts.
- Device provisioning: active node-gateway assignment follows successful physical `cmd=2` acknowledgement.
- Alarm: caution/warning/danger occurrence-count model.

## Open decisions

- Exact SMS/Telegram/email providers for first release.
- Production hosting and storage provider.
- Physical SensorReading purge job, PostgreSQL partition interval and archival implementation after the Phase 6 default 180-day retention target.
- Whether company can edit position catalog or only assign seeded positions.
- Exact rule behavior after alarm acknowledgement while unsafe readings continue.
- Legacy data migration cutoff and coexistence window.
- Object-storage provider and browser-to-provider transfer mechanism for `BuildingPlanImage.storageKey`. Phase 3 persists and audits image metadata only; no unapproved local or cloud provider adapter was introduced.
- Exact hardware unregister/remove-node or full replacement command for physical node unassignment.

## Verification record

The API entry point and E2E setup load `apps/api/.env` through `dotenv/config`. The verified redacted target is `postgresql://<redacted>:<redacted>@localhost:5432/gss_iot_v3?schema=public`, and `current_database()` returned exactly `gss_iot_v3`.

The database-backed integration suite is `apps/api/test/e2e/health.e2e-spec.ts` and `apps/api/test/e2e/rbac.e2e-spec.ts`. It verifies Prisma-backed API startup plus GSS super-admin bypass, inactive-user rejection, missing-permission rejection, same-company cross-building scope denial, cross-company scope denial, and GSS-token rejection on company endpoints. No standalone integration-test script is configured.

Phase 2 UI verification includes `packages/ui/test/theme.spec.ts`, `packages/ui/test/node-type-card.spec.tsx`, `apps/web/src/test/App.spec.tsx`, `apps/web/src/test/rbac.spec.ts` and `apps/web/e2e/bootstrap.spec.ts`. The browser suite verifies the public `/phase-2/demo` route renders all three legacy node-type images and captures a non-empty node-card screenshot buffer.

Phase 3 verification includes `apps/api/test/e2e/rbac.e2e-spec.ts`. It now covers GSS creation of a company and platform manager, Company platform-manager area/building mutations, foreign-company position-scope rejection, GSS-only direct-permission rejection, last platform-manager self-deactivation rejection, and audit-log creation.

Phase 4 verification includes `apps/api/test/e2e/devices.e2e-spec.ts`. It covers authorized GSS device inventory creation and assignment, missing permission, direct deny, inactive company user login rejection, company/area/building scope denial, cross-company assignment rejection, validation errors, gateway/node move history, super-admin bypass and audit-log creation. Combined E2E was run against a temporary PostgreSQL schema so fixture cleanup did not touch normal development seed data.

Phase 5 verification includes `apps/api/test/gateway-commands.spec.ts` and `apps/api/test/e2e/gateway-commands.e2e-spec.ts`. It covers topic generation, typed payload adapters, transition validation, malformed MQTT payload handling, MQTT-disabled and fake-ack modes, GSS command permissions, direct deny, inactive user, invalid gateway and payload validation, persisted-before-publish command creation, fake publish acknowledgement, retry, cancel, expiration, super-admin bypass and GatewayCommand audit logs.

Phase 6 verification includes `apps/api/test/monitoring.spec.ts`, `apps/api/test/e2e/monitoring.e2e-spec.ts` and `apps/web/src/test/monitoring.spec.tsx`. It covers door/angle/gangform parser normalization, malformed/mismatched payload rejection, valid reading persistence, latest-state upsert, duplicate message dedupe, building/node-type filtering, paginated history, company scope denial, cross-company denial, authorized Socket.IO room join, unauthorized room rejection, correct-room realtime emission and the Company monitoring card route.

Phase 7 verification includes `apps/web/src/test/auth-routing.spec.tsx`. It covers GSS login -> Companies -> Open -> company detail without login redirect, authenticated deep-link/session restoration, expired stored session cleanup and login redirect, authenticated unknown admin route NotFound, missing permission Forbidden and wrong-context portal denial. Phase 7 reuses the existing backend E2E coverage for `/auth/gss/me`, `/auth/company/me`, GSS-token rejection on company endpoints and protected organization/device APIs; no backend API or schema change was required.

Phase 8 verification includes `apps/api/test/gateway-commands.spec.ts`, `apps/api/test/e2e/gateway-commands.e2e-spec.ts`, updated `apps/api/test/e2e/devices.e2e-spec.ts` cleanup/expectations, `apps/web/src/test/devices.spec.tsx` and `apps/web/src/test/gateway-commands.spec.tsx`. It covers strict response parsing, legacy `resp: "success"` and `resp: "fail"` parsing, requestId payload stamping for cmd 2/3/4/5, retry requestId reuse, exact requestId success/failure, malformed/unknown/wrong-gateway/wrong-cmd requestId rejection without fallback, strict legacy no-requestId matching, ambiguous legacy no-op behavior, fast ACK before SENT, numeric cmd 2/cmd 5 node-array MQTT wire payloads, invalid and numerically duplicated node-number rejection before command persistence, successful cmd 2 ACK assignment creation, cmd 2 mismatch failure without assignment, pending/offline no-assignment state, negative ACK failure, expiration/cancellation/late ACK no-op behavior, duplicate ACK idempotency, retry without duplicate assignment, cross-company rejection, wrong-building rejection, mixed node-type rejection, already-assigned node rejection, super-admin/permission behavior, selector-based Admin provisioning UI, MQTT disabled/connected/disconnected status, subscription status, publish success/failure state, protected sanitized MQTT status API and MQTT status UI rendering.

Phase 8 live hardware verification completed on 2026-07-18 with selected gateway `0300` and acknowledged `GatewayCommand` `160b3e5c-139d-479b-8535-a82f25f95b02`. The stored/published `cmd=2` payload was `{"cmd":2,"nodes":[100,101,102],"nodeType":2,"numNodes":3,"requestId":"160b3e5c-139d-479b-8535-a82f25f95b02"}`. The ACK payload was `{"cmd":2,"resp":"success","nodes":[100,101,102],"nodeType":2,"numNodes":3,"requestId":"160b3e5c-139d-479b-8535-a82f25f95b02"}`. DB and protected Admin API verification confirmed nodes `100`, `101` and `102` each have exactly one active `NodeGatewayAssignment`, all point to gateway `0300`, every `sourceCommandId` equals the acknowledged command id, duplicate active assignment groups equal `0`, and audit side effects are idempotent with one `gateway-command.acknowledge` audit and one `node-gateway-provisioning.apply` audit.

Phase 6 final commands passed: `pnpm install --frozen-lockfile`, `pnpm format:check`, `pnpm lint`, `pnpm typecheck`, `pnpm test`, `pnpm build`, `pnpm test:e2e`, `pnpm --filter api exec prisma migrate deploy`, `pnpm --filter api exec prisma migrate status`, two runs of `pnpm --filter api exec prisma db seed` and `git diff --check`. `git diff --check` reported only Git line-ending warnings on Windows.

Phase 7 final commands passed: `pnpm format:check`, `pnpm lint`, `pnpm typecheck`, `pnpm test`, `pnpm test:e2e`, `pnpm build` and `git diff --check`. `git diff --check` reported only Git line-ending warnings on Windows.

Phase 8 automated verification commands passed on 2026-07-18: `pnpm format`, `pnpm format:check`, `pnpm lint`, `pnpm typecheck`, `pnpm test`, `pnpm test:e2e`, `pnpm build`, `pnpm --filter api exec prisma generate`, `pnpm --filter api exec prisma migrate deploy`, `pnpm --filter api exec prisma migrate status`, `pnpm --filter api exec prisma db seed` and `git diff --check`. `git diff --check` reported only Git line-ending warnings on Windows.

API, web, contracts, config and UI unit suites, API E2E, lint, typecheck, build and browser E2E pass.

Runtime CORS verification covers `http://localhost:5173`, `http://127.0.0.1:5173`, unknown-origin rejection, GSS login followed by `/auth/gss/me`, company login CORS behavior and no-cookie bearer-token responses.

## Next action

Await an explicit Phase 9 prompt before beginning alarm levels, fault filters, alarm classification, alarm occurrence counting, notifications, reports, partitioning or archival work.
